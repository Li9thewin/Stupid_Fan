#include "main.h"                  // Device header
#include "Key.h"


/**
  * 函    数：Key初始化
  * 参    数：无
  * 返 回 值：无
  */
void Key_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
  /*Configure GPIO pins : PBPin PBPin PBPin */
  GPIO_InitStruct.Pin = Key_2_Pin|Key_code_Pin|key_1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
  GPIO_InitStruct.Pin = Key_code_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

uint8_t Key_GetNum(void)
{
	uint8_t KeyNum = 0;		//默认键码为0
	
	if(HAL_GPIO_ReadPin(GPIOB,key_1_Pin) == 0)	//读取PB1输入
	{
		HAL_Delay(20);
		while(HAL_GPIO_ReadPin(GPIOB,key_1_Pin) == 0);	//等待松手
		HAL_Delay(20);
		KeyNum = 1;
	}
	
	if(HAL_GPIO_ReadPin(GPIOB,Key_2_Pin) == 0)	//读取PB1输入
	{
		HAL_Delay(20);
		while(HAL_GPIO_ReadPin(GPIOB,Key_2_Pin) == 0);	//等待松手
		HAL_Delay(20);
		KeyNum = 2;
	}
	
	if(HAL_GPIO_ReadPin(GPIOB,Key_code_Pin) == 1)	//读取PB10输入
	{
		HAL_Delay(20);
		while(HAL_GPIO_ReadPin(GPIOB,Key_code_Pin) == 1);	//等待松手
		HAL_Delay(20);
		KeyNum = 3;
	}
	
	return KeyNum;
}
