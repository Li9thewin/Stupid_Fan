/***************************************************
 * @brief   ң�кͶ������
 * @date    2024/12/16
 * @author  ĩʱ�壨csdnͬ����
****************************************************/
#include <main.h>
#include <adc.h>
#include <servo.h>
#include <yaogan_add_servo.h>

uint8_t angle_Horizontal=100;
uint8_t angle_Vertical=180;

void yaogan_control_servo(__IO uint16_t ADC_IN[2])
{
		if(ADC_IN[1]>3800)
		{
			if(angle_Horizontal>0)
			angle_Horizontal -= 5;
			SET_angle_2(angle_Horizontal);
			HAL_Delay(50);
		}
		else if(ADC_IN[1]<1500)
		{
			if(angle_Horizontal<180)
			angle_Horizontal += 5;
			SET_angle_2(angle_Horizontal);
			HAL_Delay(50);
		}
		if(ADC_IN[0]>3800)
		{
			if(angle_Vertical<180)
			angle_Vertical += 5;
			SET_angle_1(angle_Vertical);
			HAL_Delay(50);
		}
		else if(ADC_IN[0]<1500)
		{
			if(angle_Vertical>130)
			angle_Vertical -= 5;
			SET_angle_1(angle_Vertical);
			HAL_Delay(50);
		}
}

void yaogan_init(__IO uint16_t ADC_IN[2])
{
		HAL_ADC_Start_DMA(&hadc1,(uint32_t*)ADC_IN,2);
				//��̨
		//��180-130    180��   ������H12  ����
		SET_angle_1(180);
		//�� 100��         ������H13     ����
		SET_angle_2(100);
}
