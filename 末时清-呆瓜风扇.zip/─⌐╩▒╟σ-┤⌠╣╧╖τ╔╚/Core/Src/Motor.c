#include "main.h"                  // Device header
#include "Motor.h"
#include "tim.h"
/**
  * 函    数：直流电机初始化
  * 参    数：无
  * 返 回 值：无
  */
void Motor_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
  GPIO_InitStruct.Pin = Motor_AIN1_Pin|Motor_AIN2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);
}

/**
  * 函    数：直流电机调速
  * 参    数：Speed代表直流电机转速，Speed>0正转，Speed<0反转
  * 返 回 值：无
  */
void Motor_SetSpeed(int64_t Speed)
{
	if(Speed >= 0)		//正转
	{
		//设置电机驱动AIN1、AIN2引脚控制电机转向
		HAL_GPIO_WritePin(GPIOA,Motor_AIN1_Pin,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOA,Motor_AIN2_Pin,GPIO_PIN_SET);
		
		__HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_2,Speed);
	}
	
	else				//反转
	{
		//设置电机驱动AIN1、AIN2引脚控制电机转向
		HAL_GPIO_WritePin(GPIOA,Motor_AIN1_Pin,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOA,Motor_AIN2_Pin,GPIO_PIN_RESET);
		
		__HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_2,Speed);
	}
}
