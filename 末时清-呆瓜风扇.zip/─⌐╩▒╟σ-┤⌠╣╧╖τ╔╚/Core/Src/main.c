/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "Motor.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "OLED.h"
#include "Key.h"
#include "Encoder.h"
#include "DHT11.h"
#include "Servo.h"
#include "yaogan_add_servo.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
uint8_t KeyNum;			//��������
uint8_t ON;				//�Ƿ񿪻�(ON=1����ON=0�ػ�
uint8_t Auto;			//Auto=1Ϊ�Զ�ģʽ��Auto=0Ϊ�ֶ�ģʽ
uint64_t Speed;			//����ٶȣ�0~100������ʼΪ0
uint8_t Lock = 1;		//�ٶ��Ƿ�����������Ϊ1��δ����Ϊ0��Ĭ��������
uint8_t Humidity;		//ʪ��ֵ
uint8_t Temperature;	//�¶�ֵ
unsigned char tempChar[2] = {0};

DHT11_Data_TypeDef DHT11_Data;	//DHT11ģ����Ҫ�Ľṹ��

//USART
#define REC_LENGTH  20
#define MAX_REC_LENGTH  20 
char str[32];
unsigned char RxBuff[MAX_REC_LENGTH] = {0}; //USART1�洢��������
unsigned char Rx_flag= 0;                   //USART1������ɱ�־
unsigned int  UART1_Rx_cnt = 0;                   //USART1�������ݼ�����
unsigned char DataBuff[100] = {0};       //USART1�������ݻ���
int Rx_len=0;
unsigned int current1=0;   
unsigned int current2=1;   
uint8_t buf[1];
uint8_t text[1];
unsigned char warning[5]={'e','r','r','o','r'};
unsigned char next[2]={'\r','\n'};
int flag_yaotou = 0;
int flag_zuoyao=0;
int flag_youyao=0;
int flag_shang=0;
int flag_xia=0;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/* �������ƺ��� */
void Key_Control(void)
{
	KeyNum = Key_GetNum();	//���밴������
	
	if(KeyNum == 1)		//����1�ż����������л��Զ�/�ֶ�ģʽ
	{
		ON = 1;		//��Ϊ����״̬
		
		//�л��Զ�/�ֶ�ģʽ
		if(Auto == 0)
		{
			Auto = 1;
		}
		else if(Auto == 1)
		{
			Auto = 0;
			Speed = 50;	//�ֶ�ģʽĬ��ת��Ϊ50
			Lock = 1;	//Ĭ����ת������Ϊ����״̬������ת��ť���ı�ת�٣�
		}
		
		OLED_ShowString(3,10,"XX");	//���ʪ��ֵ����ʾ
	}
	
	else if(KeyNum == 3)	//����3�ż��ػ�������ת��Ϊ0������ת��
	{
		Speed = 0;
		Lock = 1;
		Auto = 0;
		ON = 0;
		OLED_ShowString(3,10,"XX");	//���ʪ��ֵ����ʾ
	}
	
	else if(ON && Auto==0)	//�ֶ�ģʽ״̬��
	{
		if(KeyNum == 2 && Lock)	//����2�ż�����������ת������������/����ת��
			Lock = 0;
		else if(KeyNum == 2 && Lock == 0)
			Lock = 1;
	}

}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{

}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance==USART1)
	{
		DataBuff[Rx_len++]=RxBuff[0];       //�����ж�ÿ��ֻ����һ���ֽ�
		Rx_flag=0;
		RxBuff[0]=0;
		HAL_UART_Receive_IT(&huart1,(uint8_t*)&RxBuff,1);
	}
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
__IO uint16_t ADC_IN[2];
/* USER CODE END 0 */
uint16_t angle=100;
uint16_t angle_updown=180;
int flag_zuo=1;
int flag_you=0;
/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
	MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();

  /* USER CODE BEGIN 2 */
	OLED_Init();
	Key_Init();
	Encoder_Init();
	DHT11_GPIO_Config();
	Motor_Init();
    Servo_init();
	yaogan_init(ADC_IN);
	OLED_ShowString(1,1,"Speed:");
	OLED_ShowString(3,1,"Humidity:XX");
  /* USER CODE END 2 */
	
	

	HAL_UART_Receive_IT(&huart1,(uint8_t *)&RxBuff,1);
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	/* ��ѭ�� */

	while(1)
	{
				/* ��ȡDHT11���� */
		if(Read_DHT11(&DHT11_Data) == SUCCESS)
		{
			Humidity = DHT11_Data.humi_int;
			Temperature = DHT11_Data.temp_int;
		}
		HAL_UART_Receive_IT(&huart1,(uint8_t *)&RxBuff,1);
    /* USER CODE END WHILE */
    /* USER CODE END WHILE */
    current1=Rx_len;
    HAL_Delay(5);
    current2=Rx_len;
    if ( current1!=0) {
			if(current1==current2)
			{

				//Rx_flag=1;
				unsigned char number=9;
				unsigned char dest[20] = {0};
				strncpy((char *)dest,(char *)DataBuff,Rx_len);
				//AL_UART_Transmit(&huart1,DataBuff,Rx_len,0x10);
				Rx_len=0;
				if(strcmp((char *)dest,"1")==0)
				{
					Speed = 0;
					Lock = 1;
					Auto = 0;
					ON = 0;
					OLED_ShowString(3,10,"XX");	//���ʪ��ֵ����ʾ
				}
				if(strcmp((char *)dest,"2")==0)
				{
					ON = 1;
					Auto = 0;
					Speed = 50;	//�ֶ�ģʽĬ��ת��Ϊ50
					Lock = 1;	//Ĭ����ת������Ϊ����״̬������ת��ť���ı�ת�٣�
				}		
				if(strcmp((char *)dest,"3")==0)
				{
					ON = 1;
					Auto = 1;
				}		
				if(strcmp((char *)dest,"4")==0)
				{
					ON = 1;
					Auto = 0;
					Speed = 50;	//�ֶ�ģʽĬ��ת��Ϊ50
					Lock = 0;	//Ĭ����ת������Ϊ����״̬������ת��ť���ı�ת�٣�
				}		
				if(strcmp((char *)dest,"5")==0)
				{
					ON = 1;
					Auto = 0;
					Speed = 50;	//�ֶ�ģʽĬ��ת��Ϊ50
					Lock = 1;	//Ĭ����ת������Ϊ����״̬������ת��ť���ı�ת�٣�
				}		
				if(strcmp((char *)dest,"6")==0)
				{
					ON = 1;
					Speed = 25;	//�ֶ�ģʽĬ��ת��Ϊ50
				}
				else if(strcmp((char *)dest,"7")==0)
				{
					ON = 1;
					Speed = 60;	//�ֶ�ģʽĬ��ת��Ϊ50
				}		
				else if(strcmp((char *)dest,"8")==0)
				{
					ON = 1;
					Speed = 90;	//�ֶ�ģʽĬ��ת��Ϊ50
				}	
				if(strcmp((char *)dest,"9")==0)
				{
					flag_yaotou=1;
					flag_zuoyao=0;
					flag_youyao=0;
					flag_shang=0;
					flag_xia=0;
				}
				if(strcmp((char *)dest,"10")==0)
				{
					flag_zuoyao=1;
					flag_yaotou=0;
					flag_youyao=0;
					flag_shang=0;
					flag_xia=0;
				}
				if(strcmp((char *)dest,"11")==0)
				{
					flag_youyao=1;
					flag_yaotou=0;
					flag_zuoyao=0;
					flag_shang=0;
					flag_xia=0;
				}
				if(strcmp((char *)dest,"12")==0)
				{
					flag_shang=1;
					flag_yaotou=0;
					flag_zuoyao=0;
					flag_youyao=0;
					flag_xia=0;
				}
				if(strcmp((char *)dest,"13")==0)
				{
					flag_xia=1;
					flag_yaotou=0;
					flag_zuoyao=0;
					flag_youyao=0;
					flag_shang=0;
				}
				if(strcmp((char *)dest,"14")==0)
				{
					flag_yaotou=0;
					flag_zuoyao=0;
					flag_youyao=0;
					flag_shang=0;
					flag_xia=0;
				}
				if(strcmp((char *)dest,"15")==0)
				{
					tempChar[0]=Temperature/10+48;
					tempChar[1]=Temperature%10+48;
					HAL_UART_Transmit(&huart1,tempChar,2,0x10);
				}
				//HAL_GPIO_TogglePin(GPIOB,red_Pin);
				//UART1_Rx_cnt=Rx_len;
				//printf("DataBuff:%s\r\n",(char*)&DataBuff);
				if ( Rx_len<100) {
				//HAL_UART_Transmit(&huart1,DataBuff,Rx_len,0x10);
				//HAL_UART_Transmit(&huart1,next,2,0x10);
				RxBuff[0]=0;       //�������Ҫ�ѻ���������
				Rx_len=0;          //�������Ҫ�ѱ�־λ����
				Rx_flag=0;         //�������Ҫ�ѱ�־λ����
				memset(DataBuff,0x00,sizeof(DataBuff));//�������Ҫ������������
				} 
			}
    }
		/* ���ð������ƺ��� */
		Key_Control();
		if(flag_yaotou==0)
			yaogan_control_servo(ADC_IN);
		/* ���� */
		if(Auto == 1)	//�Զ�ģʽ����
		{
			Speed = Humidity;
		}
		
		else	//�ֶ�ģʽ����
		{
			if(Lock == 0)
				Speed += Encoder_Get();
		}
		
		if(Speed > 100)		//����������������ת��Ϊ100
			Speed = 100;
		
		
		Motor_SetSpeed(Speed*200);		//�������
		
		
		/* OLED��ʾ��Ϣ */
		OLED_ShowNum(1,7,Speed,3);	//OLEDʵʱ��ʾ��ǰ�ٶ�ֵ

		if(Auto)	//�Զ�ģʽ��ʾ����Ϣ
		{
			OLED_ShowString(2,1,"(Auto)       ");
			OLED_ShowNum(3, 10, Humidity, 2);
		}
		
		else	//�ֶ�ģʽ��ʾ����Ϣ
		{
			if(Lock)	//ת�ٱ�����
				OLED_ShowString(2,1,"(Locked)     ");
			else	//�ֶ�����ת��
				OLED_ShowString(2,1,"Manual Adjust");
		}
		
		if(ON)	//����״̬��ʾ��Ϣ
		{
			if(Auto == 1)	//�Զ�ģʽ
				OLED_ShowString(4,1,"Auto Mode  ");
			else if(Auto == 0)	//�ֶ�ģʽ
				OLED_ShowString(4,1,"Manual Mode");
		}
		
		else	//�ػ�״̬
		{
			OLED_ShowString(4,1,"Power OFF  ");
		}
		
	}
}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM3)
    {
			if(flag_yaotou==1)
			{
				SET_angle_2(angle);
				if(angle>50 && flag_zuo==1)
				{
					angle=angle-5;
				}
				else
				{
					flag_zuo=0;
					flag_you=1;
				}
				if(angle<150 && flag_you==1)
				{
					angle=angle+5;
				}
				else
				{
					flag_zuo=1;
					flag_you=0;
				}

			}
			else if(flag_zuoyao==1)
			{
				SET_angle_2(angle);
				if(angle>50)
				{
					angle=angle-5;
				}
			}
			else if(flag_youyao==1)
			{
				SET_angle_2(angle);
				if(angle<150)
				{
					angle=angle+5;
				}
			}
			else if(flag_shang==1)
			{
				SET_angle_1(angle_updown);
				if(angle_updown>130)
				{
					angle_updown=angle_updown-5;
				}
			}
			else if(flag_xia==1)
			{
				SET_angle_1(angle_updown);
				if(angle_updown<180)
				{
					angle_updown=angle_updown+5;
				}
			}
    }



	__HAL_TIM_CLEAR_FLAG(&htim3,TIM_FLAG_UPDATE);
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
