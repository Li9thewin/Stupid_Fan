#include <main.h>
#include <tim.h>

uint16_t pwm_angle(uint8_t angle)
{
	return angle*2000/180+500;
}

void SET_angle_1(uint8_t angle)
{
		__HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_3,pwm_angle(angle));
}

void SET_angle_2(uint16_t angle)
{
		__HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_4,pwm_angle(angle));
}

void Servo_init(void)
{
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_4);
}