#include "main.h"                  // Device header
#include "Encoder.h"

int8_t Encoder_Count;

/**
  * 函    数：旋转编码器初始化
  * 参    数：无
  * 返 回 值：无
  */
void Encoder_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = GPIO_A_EXIT4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIO_A_EXIT4_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = GPIO_B_EXIT5_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIO_B_EXIT5_GPIO_Port, &GPIO_InitStruct);
}

/**
  * 函    数：旋转编码器获取增量值
  * 参    数：无
  * 返 回 值：自上此调用此函数后，旋转编码器的增量值
  */
int8_t Encoder_Get(void)
{
	int8_t Temp;
	Temp = Encoder_Count;
	Encoder_Count = 0;
	return Temp;
}

/**
  * 函    数：EXTI15_10外部中断函数
  * 参    数：无
  * 返 回 值：无
  * 注意事项：此函数为中断函数，无需调用，中断触发后自动执行
  *           函数名为预留的指定名称，可以从启动文件"startup_stm32f10x_md.s"复制
  *           请确保函数名正确，不能有任何差异，否则中断函数将不能进入
  *			  旋转编码器无消抖处理
  */


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == GPIO_B_EXIT5_Pin)
	{
				
				if(HAL_GPIO_ReadPin(GPIO_A_EXIT4_GPIO_Port,GPIO_A_EXIT4_Pin) == GPIO_PIN_SET)
			{
				HAL_Delay(5);
				Encoder_Count--;
				HAL_Delay(10);
			}
	}
	if(GPIO_Pin == GPIO_A_EXIT4_Pin)
	{
				if(HAL_GPIO_ReadPin(GPIO_B_EXIT5_GPIO_Port,GPIO_B_EXIT5_Pin) == GPIO_PIN_SET)
			{
				HAL_Delay(5);
				Encoder_Count++;
				HAL_Delay(10);
			}
	}
	

}


