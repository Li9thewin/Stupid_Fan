#ifndef __YAOGAN_ADD_SERVO_H
#define __YAOGAN_ADD_SERVO_H



void yaogan_control_servo(__IO uint16_t ADC_IN[2]);
//����ADC��ȡDMA����
void yaogan_init(__IO uint16_t ADC_IN[2]);

#endif



