#ifndef __SOUND_USART_H
#define __SOUND_USART_H


void revice_data();

void return_data();

#endif