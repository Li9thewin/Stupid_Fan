#ifndef __SERVO_H
#define __SERVO_H

void SET_angle_1(uint8_t angle);
void SET_angle_2(uint16_t angle);
void Servo_init(void);

#endif


